package org.ontoware.text2onto.bayes;
 
import org.ontoware.text2onto.pom.POMRelation;


public class Constraint {
 
	private String m_sClass;

	private String m_sLabel;


	private Boolean m_bSymmetric;

	private Boolean m_bTransitive;

	private Boolean m_bReflexive;


	protected Constraint( String sClass ){ 
		m_sClass = sClass;		
	}

	protected Constraint( String sClass, String sLabel ){
		this( sClass );
		m_sLabel = sLabel;
	}

	protected void setSymmetric( boolean bSymmetric ){
		m_bSymmetric = new Boolean( bSymmetric );
	}

	protected Boolean getSymmetric(){
		return m_bSymmetric;
	}

	protected void setTransitive( boolean bTransitive ){
		m_bTransitive = new Boolean( bTransitive );
	}

	protected Boolean getTransitive(){
		return m_bTransitive;
	}

	protected void setReflexive( boolean bReflexive ){
		m_bReflexive = new Boolean( bReflexive );
	}

	protected Boolean getReflexive(){
		return m_bReflexive;
	}
 
	protected boolean matches( POMRelation relation ){
		return ( ( m_sClass == null || relation.getClass().toString().endsWith( m_sClass ) )
			&& ( m_sLabel == null || relation.getLabel().equals( m_sLabel ) ) );
	}
}