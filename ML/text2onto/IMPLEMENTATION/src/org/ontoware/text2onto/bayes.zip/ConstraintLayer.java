package org.ontoware.text2onto.bayes;

import java.util.List;
import java.util.ArrayList;
import java.util.Hashtable; 
import java.util.Iterator;

import org.ontoware.text2onto.pom.POMObject;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMRelation;
 
import edu.ksu.cis.bnj.ver3.core.*;
import edu.ksu.cis.bnj.ver3.core.values.*;


public class ConstraintLayer extends AbstractLayer {
 
	protected Hashtable m_htNode2Constraints;

	private int m_iType = -1;

	public final static int SYMMETRY = 0;

	public final static int TRANSITIVITY = 1;

	private int m_iNode = 0;


	protected ConstraintLayer( CombinationLayer layer, List constraints, int iType ){
		m_htObject2Nodes = new Hashtable();
		m_htNode2Constraints = new Hashtable();
		m_alNodes = new ArrayList();
		m_net = layer.getBeliefNetwork();
		m_pom = layer.getPOM();
		m_super = layer;
		m_iLayer = 2;
		m_iType = iType;
		// add constraints
		Iterator iter = constraints.iterator();
		while( iter.hasNext() )
		{ 
			addConstraint( (Constraint)iter.next() );	
		}
		// create nodes
		iter = m_super.nodes(); 
		while( iter.hasNext() )
		{  
			createNode( (Node)iter.next() );
		}
	}
 
	protected void addConstraint( Constraint constraint ){ 
		Iterator iter = m_super.nodes(); 
		while( iter.hasNext() )
		{
			Node node = (Node)iter.next();
			POMObject object = (POMObject)node.getObject();
			if( object instanceof POMRelation )
			{ 
				if( constraint.matches( (POMRelation)node.getObject() ) )
				{
					ArrayList al = (ArrayList)m_htNode2Constraints.get( node );
					if( al == null ){
						al = new ArrayList(); 
						m_htNode2Constraints.put( node, al );
					}
					al.add( constraint );
				}
			}
		}
	}

	protected void createNode( Node node ){ 
		List constraints = (List)m_htNode2Constraints.get( node );
		if( constraints == null )
		{  
			POMObject object = (POMObject)node.getObject();
			String sLabel = m_iLayer +"("+ m_iType +")_"+ object.toString();  
			Discrete domain = new Discrete();
			domain.addName( "false" );
			domain.addName( "true" ); 
										
			Node newNode = new Node( sLabel, domain );
			newNode.addInputNode( node );
			newNode.setObject( object ); 

			m_net.addBeliefNode( newNode );
			m_net.connect( node, newNode );
	
			CPF cpf = newNode.getCPF();
			cpf.put( new int[]{ 1, 1 }, new ValueDouble( 1 ) );					
			cpf.put( new int[]{ 1, 0 }, new ValueDouble( 0 ) );
			cpf.put( new int[]{ 0, 1 }, new ValueDouble( 0 ) );
			cpf.put( new int[]{ 0, 0 }, new ValueDouble( 1 ) );					
			// System.out.println( newNode.cpf2String() ); 

			addNode( newNode ); 
		} 
		else 
		{
			createConstraintNodes( node );
		}
	}

	protected void createConstraintNodes( Node node ){
		List constraints = (List)m_htNode2Constraints.get( node );		
		Iterator iter = constraints.iterator();
		while( iter.hasNext() )
		{
			Constraint constraint = (Constraint)iter.next();
			POMRelation rel = (POMRelation)node.getObject();
			switch( m_iType )
			{
				case( SYMMETRY ):		
					if( rel.getDomain().getClass().equals( rel.getRange().getClass() ) )
					{ 
						Boolean b = constraint.getSymmetric();
						if( b != null ){		
							createSymmetryNodes( node, rel, b.booleanValue() );
						} 
					}
					break;
				case( TRANSITIVITY ):
					if( rel.getDomain().getClass().equals( rel.getRange().getClass() ) )
					{ 
						Boolean b = constraint.getTransitive();
						if( b != null ){						
							createTransitivityNodes( node, rel, b.booleanValue() );
						} 			
					}
					break;
			}			
		}
	} 

	private void createSymmetryNodes( Node node, POMRelation rel, boolean bSymmetric ){
		POMRelation inv = m_pom.getInverse( rel ); 
		if( inv == null 
			|| getFirstNode( rel ) != null || getFirstNode( inv ) != null )
		{
			return;
		}
		Node invNode = m_super.getFirstNode( inv );
		// System.out.println( "\nSymmetryConstraintLayer:\nNode="+ node +"\nInvNode="+ invNode );

		String sNode = node.getName().substring( node.getName().indexOf( "_" )+1 );
		String sInvNode = invNode.getName().substring( invNode.getName().indexOf( "_" )+1 );

		String sLabel = m_iLayer +"("+ m_iType +")_"+ sNode +"_AND_"+ sInvNode;  		

		Discrete domain = new Discrete();
		domain.addName( "both" );
		domain.addName( sNode );
		domain.addName( sInvNode );
		domain.addName( "none" ); 
									
		Node newNode = new Node( sLabel, domain );
		newNode.addInputNode( node );
		newNode.addInputNode( invNode );
		newNode.setObject( node.getObject() ); 

		m_net.addBeliefNode( newNode );
		m_net.connect( node, newNode );
		m_net.connect( invNode, newNode );

		CPF cpf = newNode.getCPF();
		for( int i=0; i<cpf.size(); i++ )
		{
			int[] iAddr = cpf.realaddr2addr(i);
			cpf.put( iAddr, new ValueDouble( 0 ) ); 
		}
		cpf.put( new int[]{ 0, 1, 1 }, new ValueDouble( 1 ) );					
		cpf.put( new int[]{ 1, 1, 0 }, new ValueDouble( 1 ) );
		cpf.put( new int[]{ 2, 0, 1 }, new ValueDouble( 1 ) );					
		cpf.put( new int[]{ 3, 0, 0 }, new ValueDouble( 1 ) );
		// System.out.println( newNode.cpf2String() );
 
		/*
		 * symmetric, antisymmetric
		 */
		String sLabel1 = m_iLayer +"("+ m_iType +")_"+ sNode; 
		String sLabel2 = m_iLayer +"("+ m_iType +")_"+ sInvNode;

		Discrete domain12 = new Discrete();
		domain12.addName( "false" );
		domain12.addName( "true" );
			
		Node newNode1 = new Node( sLabel1, domain12 );
		Node newNode2 = new Node( sLabel2, domain12 );
		newNode1.addInputNode( newNode );
		newNode2.addInputNode( newNode );
		newNode1.setObject( node.getObject() );
		newNode2.setObject( invNode.getObject() );

		m_net.addBeliefNode( newNode1 );
		m_net.addBeliefNode( newNode2 );
		m_net.connect( newNode, newNode1 );
		m_net.connect( newNode, newNode2 );
		
		CPF cpf1 = newNode1.getCPF();
		for( int i=0; i<cpf1.size(); i++ )
		{
			int[] iAddr = cpf1.realaddr2addr(i);
			cpf1.put( iAddr, new ValueDouble( 0 ) ); 
		} 
		if( !bSymmetric ){
			cpf1.put( new int[]{ 0, 0 }, new ValueDouble( 1 ) );					
			cpf1.put( new int[]{ 1, 1 }, new ValueDouble( 1 ) );	// symmetry
			cpf1.put( new int[]{ 0, 2 }, new ValueDouble( 1 ) );					
			cpf1.put( new int[]{ 0, 3 }, new ValueDouble( 1 ) );
		}
		// System.out.println( newNode1.cpf2String() );	

		CPF cpf2 = newNode2.getCPF();
		for( int i=0; i<cpf2.size(); i++ )
		{
			int[] iAddr = cpf2.realaddr2addr(i);
			cpf2.put( iAddr, new ValueDouble( 0 ) ); 
		} 
		if( !bSymmetric ){
			cpf2.put( new int[]{ 0, 0 }, new ValueDouble( 1 ) );					
			cpf2.put( new int[]{ 0, 1 }, new ValueDouble( 1 ) );
			cpf2.put( new int[]{ 1, 2 }, new ValueDouble( 1 ) );	// symmetry					
			cpf2.put( new int[]{ 0, 3 }, new ValueDouble( 1 ) ); 
		}
		// System.out.println( newNode2.cpf2String() ); 

		addNode( newNode1 );
		addNode( newNode2 );
	}

	public void createTransitivityNodes( Node node, POMRelation rel, boolean bTransitive ){
		if( rel.getDomain().equals( rel.getRange() ) ){
			return;
		}
		if( getFirstNode( rel ) != null ){
			return;
		}
		List nextRels = m_pom.getRelations( rel.getRange(), null ); 
		Iterator nIter = nextRels.iterator();
		while( nIter.hasNext() )
		{
			POMRelation nextRel = (POMRelation)nIter.next();
			Node nextNode = m_super.getFirstNode( nextRel ); 
			// System.out.println( "\nTransitivityConstraintLayer:\nNode="+ node +"\nNextNode="+ nextNode );

			List transRels = m_pom.getRelations( rel.getDomain(), nextRel.getRange() );
			Iterator tIter = transRels.iterator();
			while( tIter.hasNext() )
			{
				POMRelation transRel = (POMRelation)tIter.next();
				Node transNode = m_super.getFirstNode( transRel );
				// System.out.println( "\nTransitivityConstraintLayer:\nNode="+ node +"\nTransNode="+ transNode );

				String sNode = node.getName().substring( node.getName().indexOf( "_" )+1 );
				String sNextNode = nextNode.getName().substring( nextNode.getName().indexOf( "_" )+1 );
				String sTransNode = transNode.getName().substring( transNode.getName().indexOf( "_" )+1 );

				String sLabel = m_iLayer +"("+ m_iType +")_"+ sNode +"_AND_"+ sNextNode +"_AND_"+ sTransNode +"_"+ m_iNode; 

		 		Discrete domain = new Discrete();
				domain.addName( "all" );
				domain.addName( sNode );
				domain.addName( sNextNode );
				domain.addName( sTransNode );
				domain.addName( sNode +"_AND_"+ sNextNode );
				domain.addName( sNextNode +"_AND_"+ sTransNode );
				domain.addName( sNode +"_AND_"+ sTransNode );
				domain.addName( "none" ); 

				Node newNode = new Node( sLabel, domain );
				newNode.addInputNode( node );
				newNode.addInputNode( nextNode );
				newNode.addInputNode( transNode );
				newNode.setObject( node.getObject() );

				m_net.addBeliefNode( newNode );
				m_net.connect( node, newNode );
				m_net.connect( nextNode, newNode );
				m_net.connect( transNode, newNode );	

				CPF cpf = newNode.getCPF();
				for( int i=0; i<cpf.size(); i++ )
				{
					int[] iAddr = cpf.realaddr2addr(i);
					cpf.put( iAddr, new ValueDouble( 0 ) ); 
				}
				cpf.put( new int[]{ 0, 1, 1, 1 }, new ValueDouble( 1 ) );					
				cpf.put( new int[]{ 1, 1, 0, 0 }, new ValueDouble( 1 ) );
				cpf.put( new int[]{ 2, 0, 1, 0 }, new ValueDouble( 1 ) );					
				cpf.put( new int[]{ 3, 0, 0, 1 }, new ValueDouble( 1 ) );
				cpf.put( new int[]{ 4, 1, 1, 0 }, new ValueDouble( 1 ) );					
				cpf.put( new int[]{ 5, 0, 1, 1 }, new ValueDouble( 1 ) );
				cpf.put( new int[]{ 6, 1, 0, 1 }, new ValueDouble( 1 ) );					
				cpf.put( new int[]{ 7, 0, 0, 0 }, new ValueDouble( 1 ) );
				// System.out.println( newNode.cpf2String() );
 
				/*
				 * transitive, intransitive
				 */
				String sLabel1 = m_iLayer +"("+ m_iType +")_"+ sNode +"_"+ m_iNode; 
				String sLabel2 = m_iLayer +"("+ m_iType +")_"+ sNextNode +"_"+ m_iNode;
				String sLabel3 = m_iLayer +"("+ m_iType +")_"+ sTransNode +"_"+ m_iNode;
				m_iNode++;

				Discrete domain123 = new Discrete();
				domain123.addName( "false" );
				domain123.addName( "true" );
			
				Node newNode1 = new Node( sLabel1, domain123 );
				Node newNode2 = new Node( sLabel2, domain123 );
				Node newNode3 = new Node( sLabel3, domain123 );
				newNode1.addInputNode( newNode );
				newNode2.addInputNode( newNode );
				newNode3.addInputNode( newNode );
				newNode1.setObject( node.getObject() );
				newNode2.setObject( nextNode.getObject() );
				newNode3.setObject( transNode.getObject() );

				m_net.addBeliefNode( newNode1 );
				m_net.addBeliefNode( newNode2 );
				m_net.addBeliefNode( newNode3 );
				m_net.connect( newNode, newNode1 );
				m_net.connect( newNode, newNode2 );
				m_net.connect( newNode, newNode3 );
		
				CPF cpf1 = newNode1.getCPF();
				for( int i=0; i<cpf1.size(); i++ )
				{
					int[] iAddr = cpf1.realaddr2addr(i);
					cpf1.put( iAddr, new ValueDouble( 0 ) ); 
				} 
				if( bTransitive ){
					cpf1.put( new int[]{ 0, 0 }, new ValueDouble( 1 ) );					
					cpf1.put( new int[]{ 1, 1 }, new ValueDouble( 1 ) );
					cpf1.put( new int[]{ 0, 2 }, new ValueDouble( 1 ) );					
					cpf1.put( new int[]{ 0, 3 }, new ValueDouble( 1 ) );
					cpf1.put( new int[]{ 1, 4 }, new ValueDouble( 1 ) );					
					cpf1.put( new int[]{ 0, 5 }, new ValueDouble( 1 ) );
					cpf1.put( new int[]{ 1, 6 }, new ValueDouble( 1 ) );					
					cpf1.put( new int[]{ 0, 7 }, new ValueDouble( 1 ) );
				}
				// System.out.println( newNode1.cpf2String() );	

				CPF cpf2 = newNode2.getCPF();
				for( int i=0; i<cpf2.size(); i++ )
				{
					int[] iAddr = cpf2.realaddr2addr(i);
					cpf2.put( iAddr, new ValueDouble( 0 ) ); 
				} 
				if( bTransitive ){
					cpf2.put( new int[]{ 0, 0 }, new ValueDouble( 1 ) );					
					cpf2.put( new int[]{ 0, 1 }, new ValueDouble( 1 ) );
					cpf2.put( new int[]{ 1, 2 }, new ValueDouble( 1 ) );					
					cpf2.put( new int[]{ 0, 3 }, new ValueDouble( 1 ) ); 
					cpf2.put( new int[]{ 1, 4 }, new ValueDouble( 1 ) );					
					cpf2.put( new int[]{ 1, 5 }, new ValueDouble( 1 ) );
					cpf2.put( new int[]{ 0, 6 }, new ValueDouble( 1 ) );					
					cpf2.put( new int[]{ 0, 7 }, new ValueDouble( 1 ) ); 
				}
				// System.out.println( newNode2.cpf2String() ); 

				CPF cpf3 = newNode3.getCPF();
				for( int i=0; i<cpf3.size(); i++ )
				{
					int[] iAddr = cpf3.realaddr2addr(i);
					cpf3.put( iAddr, new ValueDouble( 0 ) ); 
				} 
				if( bTransitive ){
					cpf3.put( new int[]{ 0, 0 }, new ValueDouble( 1 ) );					
					cpf3.put( new int[]{ 0, 1 }, new ValueDouble( 1 ) );
					cpf3.put( new int[]{ 0, 2 }, new ValueDouble( 1 ) );					
					cpf3.put( new int[]{ 1, 3 }, new ValueDouble( 1 ) ); 
					cpf3.put( new int[]{ 1, 4 }, new ValueDouble( 1 ) );	// transitivity					
					cpf3.put( new int[]{ 1, 5 }, new ValueDouble( 1 ) );
					cpf3.put( new int[]{ 1, 6 }, new ValueDouble( 1 ) );					
					cpf3.put( new int[]{ 0, 7 }, new ValueDouble( 1 ) ); 
				}
				// System.out.println( newNode3.cpf2String() ); 
	
				addNode( newNode1 );
				addNode( newNode2 );
				addNode( newNode3 );
			}
		}
	}
}