package org.ontoware.text2onto.bayes;

import java.util.List;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Iterator;

import org.ontoware.text2onto.pom.POMObject;

import edu.ksu.cis.bnj.ver3.core.*;
import edu.ksu.cis.bnj.ver3.core.values.*;
import edu.ksu.cis.bnj.ver3.core.BeliefNetwork;


public class OutputLayer extends AbstractLayer {
 
	private List m_supers;

	protected OutputLayer( List layers ){
		m_htObject2Nodes = new Hashtable();
		m_alNodes = new ArrayList();	
		m_super = (AbstractLayer)layers.get(0);
		m_supers = layers;
		m_net = m_super.getBeliefNetwork();
		m_pom = m_super.getPOM();
		m_iLayer = 3;
		// create nodes
		List objects = m_pom.getObjects();
		Iterator iter = objects.iterator(); 
		while( iter.hasNext() )
		{ 
			POMObject object = (POMObject)iter.next();
			createNode( object );
		}
	}

	private List getSuperNodes( POMObject object ){
		ArrayList alNodes = new ArrayList(); 
		Iterator iter = m_supers.iterator();
		while( iter.hasNext() )
		{
			AbstractLayer layer = (AbstractLayer)iter.next();
			alNodes.addAll( layer.getNodes( object ) );			
		}
		return alNodes;
	}

	protected void createNode( POMObject object ){
		List nodes = getSuperNodes( object ); 
				
		String sLabel = m_iLayer +"_"+ object.toString();  
		Discrete domain = new Discrete();
		domain.addName( "false" );
		domain.addName( "true" ); 
										
		Node newNode = new Node( sLabel, domain );
		m_net.addBeliefNode( newNode );

		Iterator iter = nodes.iterator();
		int iAllTrue[] = new int[nodes.size()+1];
		int j=0; 
		while( iter.hasNext() )
		{
			Node objectNode = (Node)iter.next();
			newNode.addInputNode( objectNode );
			m_net.connect( objectNode, newNode );
			iAllTrue[j+1] = 1;
			j++;	
		} 
		newNode.setObject( object ); 
 
		CPF cpf = newNode.getCPF(); 
		for( int i=0; i<cpf.size(); i++ )
		{
			int[] iAddr = cpf.realaddr2addr(i);
			if( iAddr[0] == 1 ){ 
				cpf.put( iAddr, new ValueDouble( 0 ) ); 
			} else {
				cpf.put( iAddr, new ValueDouble( 1 ) );
			}
		} 
		iAllTrue[0] = 1;
		cpf.put( iAllTrue, new ValueDouble( 1 ) );	 					
		System.out.println( newNode.cpf2String() );

		addNode( newNode );
	}
}