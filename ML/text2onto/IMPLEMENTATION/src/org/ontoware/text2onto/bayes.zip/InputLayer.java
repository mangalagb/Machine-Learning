package org.ontoware.text2onto.bayes;

import java.util.Hashtable;
import java.util.ArrayList;

import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMObject;

import edu.ksu.cis.bnj.ver3.core.*;
import edu.ksu.cis.bnj.ver3.core.values.ValueDouble;


public class InputLayer extends AbstractLayer {

	protected InputLayer( BeliefNetwork net, POM pom ){
		m_htObject2Nodes = new Hashtable();
		m_alNodes = new ArrayList();	
		m_net = net;
		m_super = null;
		m_iLayer = 0;
		m_pom = pom;
	}
 
	protected void createNode( POMObject object ){
		String sLabel = m_iLayer +"_"+ object.getClass().getName() +"( "+ object +" )";
		Discrete domain = new Discrete();
		domain.addName( "false" );
		domain.addName( "true" );

		Node node = new Node( sLabel, domain );
		node.setObject( object ); 

		CPF cpf = node.getCPF();  
		cpf.put( new int[]{ 0 }, new ValueDouble( 1.0 - object.getProbability() ) ); 
		cpf.put( new int[]{ 1 }, new ValueDouble( object.getProbability() ) );
		// System.out.println( node.cpf2String() ); 
 
		m_net.addBeliefNode( node );
		addNode( node );
	}

	protected void setEvidence( POMObject object, boolean bEvidence ){
		Node node = getFirstNode( object );
		if( node != null )
		{
			DiscreteEvidence evidence = null;
			if( bEvidence ) evidence = new DiscreteEvidence( 1 );
			else evidence = new DiscreteEvidence( 0 ); 
			node.setEvidence( evidence );
		} 
		else {
			System.err.println( "InputLayer: node not found" );
		}
	}
}