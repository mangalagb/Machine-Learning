package org.ontoware.text2onto.bayes;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import org.ontoware.text2onto.pom.POMObject;

import edu.ksu.cis.bnj.ver3.core.*;


public class Node extends BeliefNode {

	private ArrayList m_alInput;
 
	private POMObject m_object;

 
	protected Node( String sLabel, Domain domain ){
		super( sLabel, domain ); 
		m_alInput = new ArrayList();
	} 

	protected void addInputNode( Node node ){
		m_alInput.add( node );
	}

	protected List getInputNodes(){
		return m_alInput;
	}
 
	protected void setObject( POMObject object ){
		m_object = object;
	}

	protected POMObject getObject(){
		return m_object;
	}
 
	public String cpf2String(){ 
		StringBuffer sb = new StringBuffer();
		CPF cpf = getCPF(); 
		BeliefNode[] dp = cpf.getDomainProduct(); 
		for( int k=0; k<dp.length; k++ )
		{
			sb.append( "\ndp["+ k +"]="+ dp[k] );
		} 
		for( int i = 0; i < cpf.size(); i++ )
		{
			int[] q = cpf.realaddr2addr(i);  
			sb.append( "\nq[i]=[ " );
			for( int j=0; j<q.length; j++ )
			{
				sb.append( q[j] +" " );
			}
			sb.append( "] -> "+ ((Value)cpf.get(i)).getExpr() );
		}
		return sb.toString(); 
	}

	public String toString(){
		return "Node( name="+ getName() +", domain="+ getDomain() +", object="+ getObject() +" )"; 
	}

	public boolean equals( Object object ){
		if( object instanceof Node )
		{
			List nodes = ((Node)object).getInputNodes();
			if( nodes.size() == m_alInput.size() )
			{
				Iterator iter = nodes.iterator();
				while( iter.hasNext() ){
					if( !m_alInput.contains( iter.next() ) )
					{
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}

	public int hashCode(){
		return m_alInput.hashCode();
	}
}