package org.ontoware.text2onto.bayes;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader; 
import java.util.StringTokenizer;

import org.ontoware.text2onto.pom.*;
import org.ontoware.text2onto.change.Add;

import edu.ksu.cis.bnj.ver3.core.*;
import edu.ksu.cis.bnj.ver3.inference.Inference;
import edu.ksu.cis.util.driver.Options;
import edu.ksu.cis.bnj.ver3.streams.*;
import edu.ksu.cis.bnj.ver3.streams.xml.*;

import edu.ksu.cis.bnj.ver3.inference.exact.LS;
// import edu.ksu.cis.bnj.ver3.inference.cutset.LoopCutset; 
// import edu.ksu.cis.bnj.ver3.inference.approximate.ptreduction.PTReductionInference;
// import edu.ksu.cis.bnj.ver3.inference.approximate.sampling.AIS;


public class BayesianNetwork {

	private BeliefNetwork m_net;
 
	private InputLayer m_inputLayer;

	private OutputLayer m_outputLayer;


	public static void main( String args[] ){
		BayesianNetwork bn = null;
		if( args.length == 0 )
		{
			bn = new BayesianNetwork();
		} 
		else {
			bn = new BayesianNetwork( args[0] );
		}
		bn.save( "h:\\todo\\text2onto\\bayes\\bn.xml" );
		bn.update();

		// POMObject object = (POMObject)pom.getConcepts().get(0); 
		// bn.setEvidence( object, true );
		// bn.update();
	}
  
	public BayesianNetwork(){ 
		m_net = createBN( createPOM() );
	}
	
  	public BayesianNetwork( String sFile ){
  		try { 
  			POM pom = createPOM( sFile );
  			// System.out.println( pom.toString() );
			m_net = createBN( pom );
		} 
		catch( IOException e ){
			e.printStackTrace();
		}		
	}

	public BayesianNetwork( POM pom ){ 
		m_net = createBN( pom );
	}
	

	public void save( String sFile ){ 
		Converter_xmlbif out = new Converter_xmlbif();
		try
		{
			out.save( new FileOutputStream( sFile ) ); 
			OmniFormatV1_Writer.Write( m_net, out );
		}
		catch( Exception e )
		{
			e.printStackTrace();
		}
	}

	public void update(){ 
		Inference inf = new LS();   
		inf.run( m_net ); 
		BeliefNode[] nodes = m_net.getNodes();
		for( int i = 0; i < nodes.length; i++ )
		{
			BeliefNode node = nodes[i]; 
			System.out.println( node.getName() +":\n"+ Options.getString( inf.queryMarginal( node ) ) + "\n" );
		} 
	} 

	public void setEvidence( POMObject object, boolean bEvidence ){
		m_inputLayer.setEvidence( object, bEvidence );
	}
 
	private BeliefNetwork createBN( POM pom ){
		BeliefNetwork net = new BeliefNetwork();
		/*
		 * input layer
		 */ 
		m_inputLayer = new InputLayer( net, pom ); 
		List objects = pom.getObjects(); 
		Iterator iter = objects.iterator();
		while( iter.hasNext() )
		{
			POMObject object = (POMObject)iter.next();
			m_inputLayer.createNode( object );
		}
		// System.out.println( "\nInputLayer:\n"+ m_inputLayer );
		/*
		 * combination layer
		 */ 
		CombinationLayer combinationLayer = new CombinationLayer( m_inputLayer );
		// System.out.println( "\nCombinationLayer:\n"+ combinationLayer );
		/*
		 * constraint layer
		 */
		List constraints = createConstraints();  
		ConstraintLayer sLayer = new ConstraintLayer( combinationLayer, constraints, ConstraintLayer.SYMMETRY );
		ConstraintLayer tLayer = new ConstraintLayer( combinationLayer, constraints, ConstraintLayer.TRANSITIVITY );
		// System.out.println( "\nSymmetryLayer:\n"+ sLayer );
		// System.out.println( "\nTransitivityLayer:\n"+ tLayer ); 
		/*
		 * output layer
		 */
		ArrayList layers = new ArrayList();
		layers.add( sLayer );
		layers.add( tLayer );
		m_outputLayer = new OutputLayer( layers );
		System.out.println( "\nOutputLayer:\n"+ m_outputLayer );
		return net;
	}

	private List createConstraints(){
		ArrayList al = new ArrayList();
		Constraint constraint = new Constraint( "org.ontoware.text2onto.pom.POMSubclassOfRelation" );
		constraint.setSymmetric( false );
		constraint.setTransitive( true );
		constraint.setReflexive( true );
		al.add( constraint );
		return al;
	}

	public String toString(){
		return m_net.toString();
	}

	/********************************* DEBUG *********************************/

	private POM createPOM(){
		POM pom = POMFactory.newPOM();

		POMConcept concept1 = new POMConcept( "C1" );
		concept1.setProbability( 0.9 );
		POMConcept concept2 = new POMConcept( "C2" );
		concept2.setProbability( 0.7 );
		POMConcept concept3 = new POMConcept( "C3" );
		concept3.setProbability( 0.2 );

		POMSubclassOfRelation rel1 = new POMSubclassOfRelation();
		rel1.setDomain( concept1 );
		rel1.setRange( concept2 );   
		rel1.setProbability( 0.8 );
		POMSubclassOfRelation rel2 = new POMSubclassOfRelation();
		rel2.setDomain( concept2 );
		rel2.setRange( concept1 );
		rel2.setProbability( 0.3 );

		POMSubclassOfRelation rel3 = new POMSubclassOfRelation();
		rel3.setDomain( concept1 );
		rel3.setRange( concept3 );
		rel3.setProbability( 0.2 );
		POMSubclassOfRelation rel4 = new POMSubclassOfRelation();
		rel4.setDomain( concept2 );
		rel4.setRange( concept3 );
		rel4.setProbability( 0.9 ); 

		ArrayList al = new ArrayList();
		al.add( new Add( null, concept1 ) );
		al.add( new Add( null, concept2 ) );
		al.add( new Add( null, concept3 ) );
		al.add( new Add( null, rel1 ) );
		al.add( new Add( null, rel2 ) );
		al.add( new Add( null, rel3 ) );
		al.add( new Add( null, rel4 ) );
		pom.apply( al );

		return pom;
	}

	private POM createPOM( String sFile ) throws IOException {
		POM pom = POMFactory.newPOM();
		ArrayList changes = new ArrayList();  
		File file = new File( sFile );
		BufferedReader reader = null;
		try {
			reader = new BufferedReader( new FileReader( file ) );
			String sLine = null;
			while( ( sLine = reader.readLine() ) != null )
			{
				sLine = sLine.trim();
				if( sLine.length() > 0 )
				{ 
					StringTokenizer st = new StringTokenizer( sLine, "()=," );
					String[] sParse = new String[st.countTokens()];
					int i=0;
					while( st.hasMoreTokens() )
					{
						sParse[i++] = st.nextToken();
						// System.out.println( "sParse["+ (i-1) +"]="+ sParse[i-1] );
					} 
					if( sParse[0].equals( "conceptFrequency" ) )
					{
						POMConcept concept = new POMConcept( sParse[1] );
						concept.setProbability( Double.parseDouble( sParse[2] ) );
						changes.add( new Add( this, concept ) ); 
					} 
					/* else if( sParse[0].equals( "instanceFrequency" ) ){
						POMInstance instance = new POMInstance( sParse[1] );
						instance.setProbability( Double.parseDouble( sParse[2] ) );
						changes.add( new Add( this, instance ) );
					} */	
					else if( sParse[0].equals( "isa" ) ){
						POMSubclassOfRelation rel = new POMSubclassOfRelation();
						POMConcept domain = pom.getConcept( sParse[1] );
						POMConcept range = pom.getConcept( sParse[2] );
						if( domain == null )
						{
							domain = new POMConcept( sParse[1] );
							domain.setProbability( 0.0 );
							rel.setDomain( domain );
						} 
						else {
							rel.setDomain( domain );
						}
						if( range == null )
						{
							range = new POMConcept( sParse[2] );
							range.setProbability( 0.0 );
							rel.setRange( range );
						}
						else {
							rel.setRange( range );
						}
						rel.setProbability( Double.parseDouble( sParse[3] ) );
						changes.add( new Add( this, rel ) );			
					}
					/* else if( sParse[0].equals( "instance-of" ) ){
						POMInstanceOfRelation rel = new POMInstanceOfRelation();
						List domains = pom.getInstances( sParse[1] );
						List ranges = pom.getConcepts( sParse[2] );
						if( domains.size() == 0 )
						{
							POMInstance domain = new POMInstance( sParse[1] );
							domain.setProbability( 0.0 );
							rel.setDomain( domain );
						} 
						else {
							rel.setDomain( (POMInstance)domains.get(0) );
						}
						if( ranges.size() == 0 )
						{
							POMConcept range = new POMConcept( sParse[2] );
							range.setProbability( 0.0 );
							rel.setRange( range );
						}
						else {
							rel.setRange( (POMConcept)ranges.get(0) );
						}
						rel.setProbability( Double.parseDouble( sParse[3] ) );
						changes.add( new Add( this, rel ) );	
					} */
				}
			}	
		} catch( IOException e ){
			e.printStackTrace();
		} finally {
			if( reader != null ) reader.close();
		} 
		pom.apply( changes );
		return pom; 
	} 
 }