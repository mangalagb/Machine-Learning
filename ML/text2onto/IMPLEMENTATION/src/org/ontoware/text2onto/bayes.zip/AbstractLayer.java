package org.ontoware.text2onto.bayes;

import java.util.List;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator; 

import org.ontoware.text2onto.pom.POM;

import edu.ksu.cis.bnj.ver3.core.BeliefNetwork;


public class AbstractLayer {

	protected POM m_pom;

	protected BeliefNetwork m_net;

	protected AbstractLayer m_super;

	protected Hashtable m_htObject2Nodes; 

	protected ArrayList m_alNodes;

	protected int m_iLayer = -1;
 

	protected void addNode( Node node ){
		Object object = node.getObject();
		ArrayList al = (ArrayList)m_htObject2Nodes.get( object );
		if( al == null )
		{
			al = new ArrayList();
			m_htObject2Nodes.put( object, al );
		}
		al.add( node );
		m_alNodes.add( node );
	}

	protected Node getFirstNode( Object object ){
		List nodes = getNodes( object );
		if( nodes != null && nodes.size() > 0 )
		{
			return (Node)nodes.get(0);
		}
		return null;
	}
 
	protected List getNodes( Object object ){
		List nodes = (List)m_htObject2Nodes.get( object );
		if( nodes == null ){
			nodes = new ArrayList();
		}
		return nodes;
	}

	protected Iterator objects(){
		return m_htObject2Nodes.keySet().iterator();
	}

	protected Iterator nodes(){
		return m_alNodes.iterator();
	}

	protected BeliefNetwork getBeliefNetwork(){
		return m_net;
	}

	protected POM getPOM(){
		return m_pom;
	}

	public String toString(){ 
		StringBuffer sb = new StringBuffer();
		Iterator iter = m_htObject2Nodes.keySet().iterator();
		int i=0;
		while( iter.hasNext() )
		{
			Object object = iter.next();
			List nodes = getNodes( object );
			sb.append( "("+ (i++) +") "+ object +"\n-> "+ nodes +"\n" );
		}
		return sb.toString();
	}
}