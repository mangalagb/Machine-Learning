package org.ontoware.text2onto.bayes;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;

import org.ontoware.text2onto.pom.POMObject;
import org.ontoware.text2onto.pom.POMEntity;
import org.ontoware.text2onto.pom.POMRelation;

import edu.ksu.cis.bnj.ver3.core.*;
import edu.ksu.cis.bnj.ver3.core.values.*;


public class CombinationLayer extends AbstractLayer {
 
	protected CombinationLayer( InputLayer layer ){
		m_htObject2Nodes = new Hashtable();
		m_alNodes = new ArrayList();
		m_net = layer.getBeliefNetwork();
		m_pom = layer.getPOM();
		m_super = layer;
		m_iLayer = 1;
		// create nodes
		Iterator iter = m_super.nodes(); 
		while( iter.hasNext() )
		{ 
			Node node = (Node)iter.next();
			createNode( node );
		}
	}

	protected void createNode( Node node ){ 
		POMObject object = (POMObject)node.getObject();
		if( object instanceof POMEntity )
		{
			POMEntity entity = (POMEntity)object;
			Node entityNode = (Node)m_super.getFirstNode( entity );
			if( entityNode != null )
			{
				String sLabel = m_iLayer +"_"+ entity.getLabel();  
				Discrete domain = new Discrete();
				domain.addName( "false" );
				domain.addName( "true" ); 
										
				Node newNode = new Node( sLabel, domain );
				newNode.addInputNode( entityNode );
				newNode.setObject( object ); 

				m_net.addBeliefNode( newNode );
				m_net.connect( entityNode, newNode );

				CPF cpf = newNode.getCPF();
				cpf.put( new int[]{ 1, 1 }, new ValueDouble( 1 ) );					
				cpf.put( new int[]{ 1, 0 }, new ValueDouble( 0 ) );
				cpf.put( new int[]{ 0, 1 }, new ValueDouble( 0 ) );
				cpf.put( new int[]{ 0, 0 }, new ValueDouble( 1 ) );					
				// System.out.println( newNode.cpf2String() );

				addNode( newNode ); 
			}
			else {
				System.err.println( "CombinationLayer: no node for "+ entity );
			}
		}
		if( object instanceof POMRelation )
		{ 
			POMRelation rel = (POMRelation)object; 
			POMEntity entity1 = (POMEntity)rel.getDomain();
			POMEntity entity2 = (POMEntity)rel.getRange();

			Node relNode = (Node)m_super.getFirstNode( rel ); 
			if( relNode != null )
			{
				Node node1 = (Node)m_super.getFirstNode( entity1 );
				Node node2 = (Node)m_super.getFirstNode( entity2 );
				if( node1 != null && node2 != null )
				{				
 					String sLabel = m_iLayer +"_"+ rel.getLabel() +"( "+ entity1.getLabel() +", "+ entity2.getLabel() +" )";  
					Discrete domain = new Discrete();
					domain.addName( "false" );
					domain.addName( "true" ); 
										
					Node newNode = new Node( sLabel, domain );
					newNode.addInputNode( relNode );
					newNode.addInputNode( node1 );
					newNode.addInputNode( node2 );
					newNode.setObject( object ); 

					m_net.addBeliefNode( newNode );
					m_net.connect( relNode, newNode ); 
					m_net.connect( node1, newNode );
					m_net.connect( node2, newNode ); 

					CPF cpf = newNode.getCPF(); 
					for( int i=0; i<cpf.size(); i++ )
					{
						int[] iAddr = cpf.realaddr2addr(i);
						if( iAddr[0] == 0 )
						{
							cpf.put( iAddr, new ValueDouble( 1 ) );
						} else if( iAddr[0] == 1 )
						{
							cpf.put( iAddr, new ValueDouble( 0 ) );
						}
					}
					cpf.put( new int[]{ 1, 1, 1, 1 }, new ValueDouble( 1 ) );					
					cpf.put( new int[]{ 0, 1, 1, 1 }, new ValueDouble( 0 ) );					
					// System.out.println( newNode.cpf2String() ); 

					addNode( newNode );
				}
			}
			else {
				System.err.println( "CombinationLayer: no node for "+ rel );
			}
		}
	}
}